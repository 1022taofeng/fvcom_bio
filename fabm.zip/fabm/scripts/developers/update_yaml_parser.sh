#!/bin/sh

git subtree pull --prefix src/yaml git@github.com:BoldingBruggeman/fortran-yaml.git master --squash
