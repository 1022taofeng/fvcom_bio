#define _FABM_DIMENSION_COUNT_ 0

#include "fabm.h"

