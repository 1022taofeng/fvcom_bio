## The **Water Ecosystems Tool (WET)** model 

WET is a new generation, open source, aquatic ecosystem model developed by Aarhus University, Denmark. 
It is based on FABM-PCLake by Fenjuan Hu et al. (2016), and include features from the original PCLake model by Jan Janse (1997), as well as selected features from CAEDYM (Hamilton and Schladow 1997) and foraging arena theory (Walters and Christensen 2007). 
The WET model is completely modularized, which allow a highly flexible configuration of the conceptual model. WET can describe interactions between multiple trophic levels, including piscivorous, zooplanktivorous and benthivorous fish, zooplankton, zoobenthos, phytoplankton and rooted macrophytes. 
The model accounts for oxygen dynamics and a fully closed nutrient cycle for nitrogen and phosphorus. In contrast to the original PCLake model, WET enable coupling to hydrodynamic models (e.g., GOTM and GETM), and a range of additional features, including a flexible configuration of the conceptual model (i.e. any number of phytoplankton groups, zooplankton etc.), bottom-shear-dependent resuspension, a choice between multiple light-limitation functions for primary producers, additional organic matter fractions, options for vertical mobility of phytoplankton, zooplankton and fish, and coupling to other biogeochemical models available through FABM.

WET was originally published in:
**WET – a new generation of flexible aquatic ecosystem modelling software**, in preparation,
by Schnedler-Meyer, N. A., Hu, F., Bolding, K., Andersen, T. K., Nielsen, A., and Trolle, D.  

FABM-PCLake was originally published in: 

**FABM-PCLake – linking aquatic ecology with hydrodynamics**, Geoscientific Model Development 9: 2271-2278,
by Hu, F., Bolding, K., Bruggeman, J., Jeppesen, E., Flindt, M. R., van Gerven, L., Janse, J. H., Janssen, A. B. G., Kuiper, J. J., Mooij, W. M., and Trolle, D. 2016. 

The original PCLake model was published in:
 
**A model of nutrient dynamics in shallow lakes in relation to multiple stable states**, Hydrobiologia 342/343: 1-8, by Janse, J. 1997.



###### If you have questions and suggestions regarding this model, please contact the AU developer team:
* Nicolas Azaña Schnedler-Meyer: nasm@bios.au.dk 
* Fenjuan Hu: fenjuan@bios.au.dk 
* Dennis Trolle: trolle@bios.au.dk                                            
* Karsten Bolding: bolding@bios.au.dk
* Anders Nielsen: an@bios.au.dk



## Major revision history
Release of WET, which replaces the FABM-PCLake repository: 25 February 2020, by Nicolas Azaña Schnedler-Meyer and AU developer team
Original implementation of FABM-PCLake in its own repository: 06 March 2017, by Fenjuan Hu and AU developer team


## Module overview
WET is comprised of 12 Fortran modules, including:

* wet_model_library.f90
* utility.f90
* resus_sed.f90
* burial.f90
* abiotic_water.f90
* abiotic_sediment.f90
* phytoplankton.f90
* macrophytes.f90
* zooplankton.f90
* zoobenthos.f90
* fish_mod.f90
* fish_dist.f90

The overall tasks of individual modules are described in brief below. 


### wet_model_library

This module is a FABM wrapper module for initialising all the modules of WET.


### utility

This module includes a day-light function, and 3 types of temperature functions that are used throughout the WET model: 

* uFunTmArrh the Arrhenius temperature function 
* uFunTmGaus the Gaussian (optimum) temperature function 
* uFunTmQ10 the Q10 temperature coefficient function


### resus_sed

This module handles resuspension and sedimention processes. 


### burial

This module includes a burial process, which is the loss of a small layer of sediment as a compensation for sediment thickening, as the model assumes that only the sediment top (e.g. 10 cm) layer actively takes part in the nutrient cycling.


### abiotic_water

This module describes the state variables which are related to microbial and abiotic processes and state variables in the water column, including: inorganic matter (IM), organic matter (POM and DOM), dissolved nutrients (ammonium, nitrate, phosphate and dissolved silica dioxide), immobilized phosphorus (absorbed phosphorus) and dissolved oxygen. 

The processes described in this module include mineralisation, nitrification, denitrification, phosphorus sorption and oxygen reaeration.  


### abiotic_sediment

This module describes the processes and state variables which are related to microbial and abiotic processes in the sediment, including: inorganic matter (IM), organic matter (POM and DOM), dissolved nutrients (ammonia, nitrate and phosphate) immobilized phosphorus (adsorbed phosphorus).

The processes described in this module include diffusion across sediment-water interface, mineralisation, nitrification, denitrification, and phosphorus sorption. The module also describes the sediment oxic layer fraction, which is an important diagnostic variable used in several process-descriptions, e.g. relating to sorption of phosphorus. Settling and resuspension processes are described in the resus_sed module.

### phytoplankton

This module describes the processes and state variables related to a phytoplankton group in both the water column and the sediment. Each phytoplankton group is accounted for in three elements including dry-weight, nitrogen and phosphorus. For diatoms, the silica concentration is not a state variables, but a diagnostic variable, as the model assumes a fixed Si/DW ratio for diatoms (i.e. 0.1).

The processes described in this module include assimilation (primary production), nutrient uptake, nitrogen fixation, respiration, excretion, mortality, oxygen consumption/production, settlement and vertical migration.

The zooplankton and zoobenthos modules influence phytoplankton through grazing.


### macrophytes

This module describes the processes and state variables related to submerged macrophytes, and is implemented as a benthic module. Macrophytes are accounted for in three elements including dry-weight, nitrogen and phosphorus, and is further subdivided into a (dynamic) shoot and root fraction.

The processes described in this module include assimilation (primary production), nutrient updake, respiration, excretion, mortality and migration. The latter relates to the user option of including a colonisation rate for macrophytes, e.g., originating from the surrounding catchment.

The macrophyte module influence resuspension described in the resus_sed module. The macrophyte module also contain the macrophytes coverage percentage, which is a key diagnostic variable used by the fish and phytoplankton modules.


### zooplankton

This module describes the processes and state variables relating to zooplankton, and is implemented as a pelagic module. Zooplankton are accounted for in three elements including dry-weight, nitrogen and phosphorus. 

The processes described in this module include phytoplankton and POM grazing and assimilation, respiration, excretion, mortality and vertical migration.

The fish module (and other zooplankton groups) can influence zooplankton through predation. 


### zoobenthos

This module describes the processes and state variables relating to zoobenthos, and is implemented as a benthic module. Zoobenthos are accounted for in three elements including dry-weight, nitrogen and phosphorus. Zoobenthos feed on detritus in the sediments, and on settled phytoplankton. 

The processes described in this module include consumption and assimilation, migration, respiration, excretion and mortality.

The fish module (and other zoobenthos groups) can influence zoobenthos through predation. 


### fish_mod

The standard fish module describes the processes and state variables relating to fish, and is implemented as a pelagic module. Fish are accounted for in three elements including dry-weight, nitrogen and phosphorus. Fish may be configured as either zooplanktivorous, benthivorous or piscivorous, or as a mix of the three.

The processes described in this module include migration, reproduction (moving biomass from adult to juvenile fish), aging (moving biomass from juvenile to adult fish), assimilation (predation on zooplankton, zoobenthos or fish), respiration, excretion and mortality.

Other fish modules can influence the fish module through predation, reproduction or aging.

This module includes three types of optional foraging arena implementations, i.e. ecopath-type (constant), based on predators, or based on food.


### fish_dist

This module is an alternative to fish_mod, and combines keeping fish as a single, depth-integrated set of variables with a function to calculate their distribution through the wate column based on e.g. food concentration, and distribute feeding, excretion and other interactions accordingly . 