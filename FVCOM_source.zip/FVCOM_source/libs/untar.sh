#!/bin/bash

item=$1

if [ ! -d $item ];
then
    [ -f $item.tgz    ] && tar xzf $item.tgz
    [ -f $item.tar.gz ] && tar xzf $item.tar.gz

    if [ "$item" == "metis" ]; then
      cd metis
      patch -p1 < ../metis-4.0.patch
      patch -p1 < ../metis-4.0.make.patch
      cd ..
    fi

    if [ "$item" == "julian" ]; then
      cd julian
      patch -p1 < ../julian.make.patch
      cd ..
    fi
fi

